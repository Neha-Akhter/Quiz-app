package com.example.quiz;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;


public class DashBoard extends AppCompatActivity implements View.OnClickListener, NavigationView.OnNavigationItemSelectedListener {
    CardView countCard,geoCard,fracCard,percentCard,operCard,timeCard;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private DrawerLayout mainDrawer;
    private Toolbar appBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);
        Toolbar appBar=findViewById(R.id.appBar);
        setSupportActionBar(appBar);
        mainDrawer=(DrawerLayout)findViewById(R.id.mainDrawer);
        actionBarDrawerToggle=new ActionBarDrawerToggle(this,mainDrawer,appBar,R.string.app_name,R.string.app_name);
        actionBarDrawerToggle.syncState();
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.drawable.ic_android_black_24dp);

        //defining cardd
        countCard=(CardView)findViewById(R.id.counting_card);
        geoCard=(CardView)findViewById(R.id.geometry_card);
        fracCard=(CardView)findViewById(R.id.fractions_card);
        percentCard=(CardView)findViewById(R.id.percentage_card);
        operCard=(CardView)findViewById(R.id.operations_card);
        timeCard=(CardView)findViewById(R.id.time_card);

        //Adding on click listeners
        countCard.setOnClickListener(this);
        geoCard.setOnClickListener(this);
        fracCard.setOnClickListener(this);
        percentCard.setOnClickListener(this);
        operCard.setOnClickListener(this);
        timeCard.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i;

        switch (v.getId()){
            case R.id.counting_card :
                i=new Intent(this,Counting.class);
                startActivity(i);
                break;
            case R.id.geometry_card :
                i=new Intent(this,Geometry.class);
                startActivity(i);
                break;
            case R.id.fractions_card :
                i=new Intent(this,Fractions.class);
                startActivity(i);
                break;
            case R.id.percentage_card :
                i=new Intent(this,Percentage.class);
                startActivity(i);
                break;
            case R.id.operations_card :
                i=new Intent(this,Operations.class);
                startActivity(i);
                break;
            case R.id.time_card :
                i=new Intent(this,Time.class);
                startActivity(i);
                break;
            default: break;
        }

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return false;
    }
}